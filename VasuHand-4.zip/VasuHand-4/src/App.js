import React from 'react';
import VasuPopup from './VasuPopup';
import VasuForm from './VasuForm';
function App()
{
  
   
    return (
      <div className="container" style={{border:"2px solid black",padding:"20px 150px",marginTop:"50px",marginBottom:"200px",width:"900px",height:"1000px", borderRadius:"10px", borderWidth:"thin medium thick 10px",boxSizing:"border-box",justifyContent:"center"}}>
        <br></br>
        <h1>Form Validation <span style={{ color: "red" }}>*</span></h1>
        <VasuForm onSubmit={VasuPopup} />
      </div>
    )
  }
export default App;
