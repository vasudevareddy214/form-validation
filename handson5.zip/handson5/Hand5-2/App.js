import React from "react";
import Draggable from "react-draggable";
import "bootstrap/dist/css/bootstrap.css";
import Card from "./Card";

function App() {
  return (
    <>
      <Card title="I can be dragged anywhere"/>
      <Card axis="x" title=" I can be dragged across (x axis)"/>
<Draggable handle="strong">
<div className="card" style={{display: "flex",height: "15rem",width: "18rem",flexDirection: "column",}}>
<strong className="cursor"><div>Drag here</div></strong>
<div style={{ overflow: "scroll" }}>
<div style={{ background: "yellow", whiteSpace: "pre-wrap" }}>I have long scrollable content with a handle{"\n" + Array(40).fill("000").join("\n")}
</div>
</div>
</div>
</Draggable>
<Draggable cancel="strong" >
  <div className="card" style={{height:"15rem",width:"18rem",flexDirection:"column"}}>
      <strong className="no-cursor">Can't drag here</strong><p></p>
  <div>Dragging here works</div>
  </div>
</Draggable>
</>
  );
}
export default App;
