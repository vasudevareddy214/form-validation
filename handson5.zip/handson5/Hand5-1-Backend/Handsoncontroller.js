const Employee = require('./Handsonmodel')
exports.addEmployee = async (req, res) => {
    const employee = req.body;
    const emp = new Employee(employee);
    await emp.save();
    res.status(201).json({success:true})
}
exports.getEmployees = async (req, res) => {
    const employees = await Employee.find();
    console.log(employees)
    res.json(employees);
}
exports.getEmployee = async (req, res) => {
    const employee = await Employee.findById(req.params.id);
    console.log(employee)
    res.json(employee);
}