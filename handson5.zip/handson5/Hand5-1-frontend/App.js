import './App.css';
import Viewemp from './result';

function App() {
  return (
    <div className="App">
      <Viewemp/>
    </div>
  );
}
export default App;
